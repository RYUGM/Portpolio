package com.example.thyex.repository;

import com.example.thyex.entity.CVD_19;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CVDRepository extends JpaRepository<CVD_19, Integer> {
}
