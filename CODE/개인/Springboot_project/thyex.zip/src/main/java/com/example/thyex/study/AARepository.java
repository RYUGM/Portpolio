package com.example.thyex.study;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AARepository extends JpaRepository<AA,Long> {

}
